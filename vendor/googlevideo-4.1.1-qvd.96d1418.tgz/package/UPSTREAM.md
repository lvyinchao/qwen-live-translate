Source: https://github.com/LuanRT/googlevideo/tree/96d1418984d00ac2797a1dafe4625d1368b5b9aa
License: MIT. Source unchanged. Generated protobuf and compiled ESM included for reproducible installation without protoc. Package scripts removed and version suffixed for this pinned vendor archive.
